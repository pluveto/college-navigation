﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using WpfNavigation.Rest.Model;

namespace WpfNavigation.Rest.Api
{
    public class MapApi
    {
        IBasicApi api;
        public MapApi(IBasicApi api)
        {
            this.api = api;
        }

        public async Task<PathRet> GetPathAsync(ulong sourceNodeId, ulong targetNodeId, ulong sourceMapId, ulong targetMapId, uint pathType, uint preferTransportType, uint departAt, uint crossType)
        {
            try
            {
                var resp = await this.api.GetPath(sourceNodeId, targetNodeId, sourceMapId, targetMapId, pathType, preferTransportType, departAt, crossType);
                return resp;
            }
            catch (RestEase.ApiException e)
            {
                throw new Exception(e.StatusCode.ToString());
            }
        }
        public enum SpeedType
        {
            Node = 0,
            Edge = 1
        }

        public async Task<SpeedRet[]> GetSpeedsAsync(ulong mapId, SpeedType type, uint departAt)
        {
            try
            {
                var resp = await this.api.GetSpeeds(mapId, (uint)type, departAt);
                return resp;
            }
            catch (RestEase.ApiException e)
            {
                throw new Exception(e.StatusCode.ToString());
            }
        }
        public async Task<PathRet> GetPathsAsync(List<NodeSimple> nodes, uint pathType, uint preferTransportType, uint departAt, uint crossType)
        {
            var req = new PathsReq { nodes = nodes.ToArray(), cross_type = crossType, depart_at = departAt, path_type = pathType, prefer_transport_type = preferTransportType };
            try
            {
                var resp = await this.api.GetPaths(req);
                return resp.GetContent();
            }
            catch (RestEase.ApiException e)
            {
                throw new Exception(e.StatusCode.ToString());
            }
        }
    }
}
