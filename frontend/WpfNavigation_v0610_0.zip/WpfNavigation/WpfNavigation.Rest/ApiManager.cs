using RestEase;
using System;
using System.Diagnostics;
using WpfNavigation.Rest.Api;

namespace WpfNavigation.Rest
{
    public class ApiManager
    {
        public IBasicApi BasicApi { get; set; }
        public MapApi Map { get; set; }
        public string BaseUrl { get;  set; }

        public ApiManager(string baseUrl)
        {
            this.BaseUrl = baseUrl;
            this.BasicApi = RestClient.For<IBasicApi>(
                baseUrl, async (request, cancellationToken) =>
                {
                    Debug.WriteLine("Request: " + request.RequestUri.AbsoluteUri);
                    if(request.Content != null)
                    {

                        var body = await request.Content.ReadAsStringAsync();
                        if (null != body)
                        {
                            Debug.WriteLine("   Body:" + body);
                        }
                    }          
                });

            this.Map = new MapApi(BasicApi);
        }
    }
}
