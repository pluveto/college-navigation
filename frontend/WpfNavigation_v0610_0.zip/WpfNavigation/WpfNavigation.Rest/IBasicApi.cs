﻿using RestEase;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using WpfNavigation.Rest.Model;

namespace WpfNavigation.Rest
{
    [Header("User-Agent", "RestEase")]
    public interface IBasicApi
    {
        // The [Get] attribute marks this method as a GET request
        // The "users" is a relative path the a base URL, which we'll provide later
        // "{userId}" is a placeholder in the URL: the value from the "userId" method parameter is used
        [Get("/path")] Task<PathRet> GetPath([Query] ulong source_node_id, [Query] ulong target_node_id, [Query] ulong source_map_id, [Query] ulong target_map_id, [Query] uint path_type, [Query] uint prefer_transport_type, [Query] uint depart_at, [Query] uint cross_type);
        [Get("/speed")] Task<SpeedRet[]> GetSpeeds([Query] ulong map_id, [Query] uint type, [Query] uint depart_time);
        [Post("/paths")] Task<Response<PathRet>> GetPaths([Body] PathsReq pathsReq);
        /*
        [Post("/auth/login")] Task<Response<LoginRet>> Login([Body] LoginReq loginReq);
        [Post("/live_stock/sign_up")] Task<Response<object>> StockSignUp([Body] StockSignUpReq signUpReq);
        [Get("/gudid")] Task<Response<UdiQueryRet>> QueryGudid([Query] string udi, [Query] bool simple);
        [Get("/live_stock/check_epc")] Task<Response<BoolRet>> CheckEpc([Query] string epc);
        [Get("/users/summary")] Task<Response<UserRet[]>> GetAllUsers();
        [Post("/general/query/{table}")]
        Task<Response<PageDataRet>>
            GeneralQuery([Path(UrlEncode = false)] string table, [Body] PageDataReq body);
        [Get("/live_stock")]
        Task<Response<LiveStockRet>> GetStockItem([Query] string epc);*/
    }
}
