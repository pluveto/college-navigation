﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace WpfNavigation.Rest.Model
{
    public class PathElement
    {
        [JsonProperty("type")]

        public string Type { get; set; } // node, port, transport
        [JsonProperty("id")]

        public ulong Id { get; set; }
        [JsonProperty("mapId")]

        public ulong mapId { get; set; }
        [JsonProperty("level")]

        public int Level { get; set; }
        public override string ToString()
        {
            return $"Type: {Type}, Id: {Id}, MapId: {mapId}, Level: {Level}";
        }
    }
}
