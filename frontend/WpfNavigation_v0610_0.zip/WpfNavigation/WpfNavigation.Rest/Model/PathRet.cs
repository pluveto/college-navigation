﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace WpfNavigation.Rest.Model
{
    public class PathRet
    {
        [JsonProperty("time")]
        public int Time { get; set; }
        [JsonProperty("path")]
        public PathElement[] Value { get; set; }
    }
}
