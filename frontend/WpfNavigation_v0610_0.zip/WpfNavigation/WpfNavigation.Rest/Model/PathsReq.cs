﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WpfNavigation.Rest.Model
{
    public class NodeSimple
    {

        public ulong nodeId { get; set; }

        public ulong mapId{ get; set; }
}
    public class PathsReq
    {
        public NodeSimple[] nodes { get; set; }
        public uint path_type { get; set; }
        public uint prefer_transport_type { get; set; }
        public uint depart_at { get; set; }
        public uint cross_type { get; set; }
    }
}
