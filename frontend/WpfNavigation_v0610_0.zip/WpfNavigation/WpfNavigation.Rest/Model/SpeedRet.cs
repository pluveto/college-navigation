﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace WpfNavigation.Rest.Model
{
    public class SpeedRet
    {
        [JsonProperty("id")]
        public ulong Id { get; set; }
        [JsonProperty("speed")]
        public double Speed { get; set; }
    }
}
