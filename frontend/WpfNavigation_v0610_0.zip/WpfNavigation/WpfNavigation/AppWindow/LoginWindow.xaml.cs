﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfNavigation.Rest;

namespace WpfNavigation.AppWindow
{
    /// <summary>
    /// LoginWindow.xaml 的交互逻辑
    /// </summary>
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();

            JObject settings = JObject.Parse(File.ReadAllText(@"../settings.json"));

            Runtime.BaseUrl = settings["BaseUrl"].ToString();
            Runtime.RebootUrl = settings["RebootUrl"].ToString();
            Runtime.DebugMode = settings["DebugMode"].Value<bool>();
            Runtime.ApiManager = new ApiManager(Runtime.BaseUrl);

            if (Runtime.DebugMode)
            {
                usernameTextBox.Text = "zzj";
                passwordTextBox.Password = "111111";
                loginButton_Click(null, null);
            }
        }
        private void loginButton_Click(object sender, RoutedEventArgs e)
        {
            var username = usernameTextBox.Text;
            if(Service.UserService.Login(username, passwordTextBox.Password))
            {
                MessageBox.Show("登录成功");
            }
            else
            {
                MessageBox.Show("用户名或密码错误","错误", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            Runtime.CurrentUsername = username;

            this.Hide();
            new MainWindow().ShowDialog();
            this.Close();
        }
    }
}
