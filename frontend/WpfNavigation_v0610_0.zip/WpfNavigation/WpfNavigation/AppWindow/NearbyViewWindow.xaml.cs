﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfNavigation.Model;

namespace WpfNavigation.AppWindow
{
    /// <summary>
    /// NearbyViewWindow.xaml 的交互逻辑
    /// </summary>
    public partial class NearbyViewWindow : Window
    {
        Model.Node startNode;
        public NearbyViewWindow(Model.Node startNode)
        {
            InitializeComponent();
            this.startNode = startNode;
        }

        private void searchBtn_Click(object sender, RoutedEventArgs e)
        {
            this.nearList.Items.Clear();
            List<KeyValuePair<Node, double>> nodes = Service.MapAlgo.SearchNearBy(this.startNode, this.radiusNum.Value, false);
            if(nodes.Count== 0)
            {
                MessageBox.Show("没有");
            }
            int i = 1;
            foreach (var kv in nodes)
            {
                var node = kv.Key;
                this.nearList.Items.Add(new NearItem{ Node = node, Index = i, Title = node.Title, Distance = Math.Floor(kv.Value) });
                i++;
            }

        }
        public delegate void SelectNodeCallBack(Node node);
        public SelectNodeCallBack NodeSelected { get; set; }
        private void nearList_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            var item = ((FrameworkElement)e.OriginalSource).DataContext as NearItem;
            if (item != null)
            {
                NodeSelected(item.Node);
                this.Close();
            }

        }
    }

    internal class NearItem
    {
        public Node Node { get; set; }
        public int Index { get; set; }
        public string Title { get; set; }
        public double Distance { get; set; }
    }

    public class NearByViewWindowVM
    {
        
    }
}
