﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfNavigation.Model;
using WpfNavigation.Service;

namespace WpfNavigation.AppWindow
{
    /// <summary>
    /// VirtualAdressSearch.xaml 的交互逻辑
    /// </summary>
    public partial class VirtualAdressSearch : Window
    {
        ulong mapId;
        uint departAt;
        public VirtualAdressSearch(ulong mapId, uint departAt)
        {
            InitializeComponent();
            this.mapId = mapId;
            this.departAt = departAt;
            keywordText.Focus();
        }
        public delegate void SelectNodeCallBack(Node node);
        public SelectNodeCallBack NodeSelected { get; set; }
        public List<MatchItem> MatchItems = new List<MatchItem>();
        private void searchBtn_Click(object sender, RoutedEventArgs e)
        {
            this.retLs.Items.Clear();
            var keywords = keywordText.Text.Trim();
            var vaddr = Service.VAddrService.FromString(keywords);
            var user = Runtime.Users[Runtime.CurrentUsername];

            if (null == vaddr)
            {
                // 搜索其他地图
                List<Node> nodes = MapAlgo.SearchTitleSubtitle(keywords, departAt);
                List<Node> vaddrNodes = VAddrService.SearchActivity(keywords, user);
                nodes.AddRange(vaddrNodes);
                if (nodes.Count == 0)
                {
                    MessageBox.Show("未找到相关结果！");
                    return;
                }
                foreach (var node in nodes)
                {
                    var map = Runtime.Maps[node.MapId];
                    this.retLs.Items.Add(new MatchItem
                    {
                        Node = node,
                        NodeId = node.Id,
                        Title = node.Title,
                        MapName = map.Name,
                        SpeedFactor = map.Speed[node.Id]
                    });
                }
                this.retLs.Items.SortDescriptions.Add(new SortDescription("SpeedFactor", ListSortDirection.Descending));



                return;
            }
            else
            {
                var matchNode = Service.VAddrService.MatchAddr(vaddr, user);
                if (matchNode == null)
                {
                    MessageBox.Show("未找到匹配的逻辑地址！");
                    return;
                }
                NodeSelected(matchNode);
                this.Close();

                return;
            }
            // MessageBox.Show("未找到匹配的地点！");
        }

        private void retLs_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            var item = ((FrameworkElement)e.OriginalSource).DataContext as MatchItem;
            if (item != null)
            {
                NodeSelected(item.Node);
                this.Close();
            }
        }
    }


    public class MatchItem
    {
        public Node Node { get; set; }
        public ulong NodeId { get; set; }
        public string Title { get; set; }
        public string MapName { get; set; }
        public double SpeedFactor { get; set; }
    }
}
