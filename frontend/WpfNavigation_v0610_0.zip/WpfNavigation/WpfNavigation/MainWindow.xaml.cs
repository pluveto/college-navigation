﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfNavigation.Model;
using WpfNavigation.Service;

namespace WpfNavigation
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            this.Title = GetTitle();
            Service.MapGraphics.LoadPort("../port.json");

            for (ulong i = 0; i < 2; i++)
            {
                OpenMapInTab(i);
            }
            if (Runtime.DebugMode)
            {
                DrawBG();
            }
            //wayPointsListBox.ItemsSource = this.wayPointsList;
        }
        private void DrawBG()
        {
            this.Width = 1400;
            this.Height = 800;
        }

        Node startNode;
        Node endNode;
        OperationMode mode;
        ObservableCollection<NodeListItem> wayPointsList = new ObservableCollection<NodeListItem>();
        private string GetTitle(Point cursor = default)
        {
            var str = $"DS Navigation - 当前用户：{Runtime.CurrentUsername}";
            str += $" ({cursor.X}, {cursor.Y})";
            return str;
        }

        private void DebugDrawTest_Click(object sender, RoutedEventArgs e)
        {
            Service.MapGraphics.Test();
        }
        Dictionary<string, Shape> cursors = new Dictionary<string, Shape>();
        enum CursorType
        {
            Start,
            End,
            WayPoint
        }

        private void MapCanvas_MouseMove(object sender, MouseEventArgs e)
        {
            if (Mouse.DirectlyOver == sender)
            {
                this.Title = GetTitle(Mouse.GetPosition(GetCurrentCanvas()));
            }

        }
        void OpenMapInTab(ulong id)
        {
            wantOpen = (int)id;

            Debug.WriteLine("Open " + id);
            var tab = Service.MapGraphics.OpenMap(MapTab, id, MapCanvas_MouseDown, MapCanvas_MouseMove);
            var timer = new System.Timers.Timer();
            timer.Interval = 100;
            timer.Elapsed += (object sender, System.Timers.ElapsedEventArgs e) =>
             {
                 MapTab.Dispatcher.Invoke(() =>
                 {
                     foreach (var tabItem in MapTab.Items)
                     {
                         var tabItm = tabItem as TabItem;
                         if((ulong)tabItm.Tag == id)
                         {
                             tabItm.IsSelected = true;
                         }
                     }
                 });
                 timer.Stop();
                 timer.Close();
             };
            timer.Start();
        }
        static string NodeToString(Node node)
        {
            if (node == null)
            {
                return "(未选择)";
            }
            var x = node.Point.X;
            var y = node.Point.Y;
            return $"Map {node.MapId} ({x}, {y})";
        }
        private void UpdateNodeTextBox()
        {
            startPointTextBox.Text = NodeToString(startNode);
            endPointTextBox.Text = NodeToString(endNode);
        }
        ulong currentMapId = 0;
        private MapAlgo.PathType pathType = MapAlgo.PathType.ShortestDistance;
        private MapAlgo.TransportType preferTransportType = MapAlgo.TransportType.Foot;
        private Level crossType = Level.Subway;
        private uint departAt = 0;

        private DateTime lastClickTime = DateTime.Now;
        private Point lastClickPoint;
        private static Node nearest;
        private void MapCanvas_MouseDown(object sender, MouseButtonEventArgs e)
        {
            /*if (e.LeftButton == MouseButtonState.Pressed)
            {
                mode = OperationMode.SelectStartPoint;
            }
            if (e.RightButton == MouseButtonState.Pressed)
            {
                mode = OperationMode.SelectEndPoint;
            }*/

            var mousePt = Mouse.GetPosition(GetCurrentCanvas());
            var currentMap = Runtime.Maps[currentMapId];
            nearest = Service.MapAlgo.GetNeareastNode(currentMap, mousePt);
            this.selectedStatus.Content = nearest.ToString();
            switch (mode)
            {
                case OperationMode.SelectStartPoint:
                    startNode = nearest;
                    break;
                case OperationMode.SelectEndPoint:
                    endNode = nearest;
                    break;
                case OperationMode.SelectWayPoint:
                    wayPointsListBox.Items.Add(new NodeListItem { Node = nearest, NodeStr = NodeToString(nearest) });
                    wayPointsListBox.SelectedIndex = wayPointsListBox.Items.Count - 1;
                    break;
                default:
                    break;
            }
            Runtime.Logger.Debug($"Click on Point({mousePt.X},{mousePt.Y}) id = {nearest.Id}");
            UpdateNodeTextBox();
            UpdateSelNodeButton();
            UpdateLocationCursor();

            if (DateTime.Now - lastClickTime < new TimeSpan(0, 0, 0, 0, 400) && Service.MapAlgo.DistanceSquare(e.GetPosition(this), lastClickPoint) < 10)
            {
                do
                {
                    // Dbclick 双击，查询点信息。
                    var ports = Service.MapAlgo.GetPortsBySourceNode(nearest);
                    Port port = null;
                    if (ports.Count == 0)
                    {
                        break;
                    }
                    if(ports.Count == 1)
                    {
                        port = ports.First();
                    }
                    if (ports.Count > 1)
                    {
                        Port up = null, down = null;
                        foreach (var item in ports)
                        {
                            if(item.Level == (uint)Level.UpStair)
                            {
                                up = item;
                            }
                            if (item.Level == (uint)Level.DownStair)
                            {
                                down = item;
                            }
                        }
                        if(up == default || down == default)
                        {
                            break;
                        }
                        var ret = MessageBox.Show("是否上楼？点是上楼，点否下楼。", "提醒", MessageBoxButton.YesNo);
                        if(ret == MessageBoxResult.Yes)
                        {
                            port = up;
                        }
                        else
                        {
                            port = down;
                        }
                    }
                    if (port.Level >= (int)Level.EnterBuilding)
                    {
                        Runtime.Logger.Information($"Open Map {port.TargetMapId}");
                        OpenMapInTab(port.TargetMapId);
                    }
                } while (false);

            }
            lastClickTime = DateTime.Now;
            lastClickPoint = e.GetPosition(this);

        }
        void UpdateWayPoints()
        {
            ResetCursor(CursorType.WayPoint);
            // remove way point cursors
            foreach (var item in cursors.ToArray())
            {
                var itemType = item.Key.Split(" ")[0];
                if (itemType == CursorType.WayPoint.ToString())
                {
                    cursors.Remove(item.Key);
                }
            }
            // re render
            foreach (var item in this.wayPointsListBox.Items)
            {
                var radius = 16;
                var nodeItem = item as NodeListItem;
                var key = CursorType.WayPoint.ToString() + " " + nodeItem.Node.Id;
                var mapId = nodeItem.Node.MapId;
                var position = nodeItem.Node.Point;

                var shape = new Rectangle();
                shape.Stroke = Brushes.BlueViolet;
                shape.StrokeThickness = 2;
                shape.Width = radius;
                shape.Height = radius;
                shape.Fill = Brushes.Transparent;
                cursors[key] = shape;

                var canvas = Runtime.CanvasDict[mapId];
                canvas.Children.Add(shape);
                Canvas.SetLeft(shape, position.X - radius / 2);
                Canvas.SetTop(shape, position.Y - radius / 2);
            }
        }

        /// <summary>
        /// 清理选点游标
        /// </summary>
        /// <param name="mapId"></param>
        /// <param name="type"></param>
        void ResetCursor(CursorType type)
        {
            foreach (var item in cursors)
            {
                var itemType = item.Key.Split(" ")[0];
                if (itemType != type.ToString())
                {
                    continue;
                }
                foreach (var canvasItem in Runtime.CanvasDict)
                {
                    var canvas = canvasItem.Value;
                    if (canvas.Children.Contains(item.Value))
                    {
                        canvas.Children.Remove(item.Value);
                    }
                }
            }
        }


        private void UpdateLocationCursor()
        {

            /// <summary>
            /// 此函数在地图上绘制游标。一般来说有起点游标和终点游标。
            /// 整个应用上，起点只能有一个，终点也只能有一个。
            /// 因此在设置起点的时候，要删掉所有地图上的起点。
            /// 在设置终点的时候，要删掉所有地图上的终点。
            /// </summary>
            /// <param name="mapId"></param>
            /// <param name="type"></param>
            /// <param name="position"></param>
            void SetLocationCursor(ulong mapId, CursorType type, Point position)
            {
                // 删掉所有地图上同类型的点
                ResetCursor(type);

                var radius = 16;
                var cursorKey = type.ToString();
                Shape shape;
                if (!cursors.TryGetValue(cursorKey, out shape))
                {
                    shape = new Ellipse();
                    shape.Stroke = (type == CursorType.Start) ? Brushes.IndianRed : Brushes.DarkBlue;
                    shape.StrokeThickness = 2;
                    shape.Width = radius;
                    shape.Height = radius;
                    shape.Fill = Brushes.Transparent;
                    cursors[cursorKey] = shape;
                }
                var canvas = Runtime.CanvasDict[mapId];
                canvas.Children.Add(shape);
                Canvas.SetLeft(shape, position.X - radius / 2);
                Canvas.SetTop(shape, position.Y - radius / 2);
            }
            if (startNode != null && startNode.MapId == currentMapId)
            {
                SetLocationCursor(currentMapId, CursorType.Start, startNode.Point);
            }
            if (endNode != null && endNode.MapId == currentMapId)
            {
                SetLocationCursor(currentMapId, CursorType.End, endNode.Point);
            }
            UpdateWayPoints();
        }

        private Canvas GetCurrentCanvas()
        {
            return Runtime.CanvasDict[currentMapId];
        }

        private void UpdateSelNodeButton()
        {
            selStartButton.IsChecked = false;
            selEndButton.IsChecked = false;
            addWayPointBtn.IsChecked = false;
            this.selStartButton.Content = "选点";
            this.selEndButton.Content = "选点";
            addWayPointBtn.Content = "添加";
            mode = OperationMode.None;
        }

        private void selStartButton_Click(object sender, RoutedEventArgs e)
        {
            var selected = (bool)this.selStartButton.IsChecked;
            this.selStartButton.Content = selected ? "(捕获...)" : "选点";
            if (selected)
            {
                mode = OperationMode.SelectStartPoint;
            }
        }

        private void selStartButton_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void selEndButton_Click(object sender, RoutedEventArgs e)
        {
            var selected = (bool)this.selEndButton.IsChecked;
            this.selEndButton.Content = selected ? "(捕获...)" : "选点";
            if (selected)
            {
                mode = OperationMode.SelectEndPoint;
            }
        }

        private void FindPath_Click(object sender, RoutedEventArgs e)
        {

        }
        Rest.Model.PathRet _prevPathRet;
        private void goButton_Click(object sender, RoutedEventArgs e)
        {
            if (SimulatorService.IsRunning)
            {
                // 停止
                simulateStart_Click(null, null);
            }
            if (startNode == endNode && wayPointsListBox.Items.Count == 0)
            {
                MessageBox.Show("搁这原地导航呢？"); return;
            }
            if (startNode == null)
            {
                MessageBox.Show("请选择起点！"); return;
            }
            if (endNode == null)
            {
                MessageBox.Show("请选择终点！"); return;
            }
            Rest.Model.PathRet ret = default;
            departAt = (uint)(departHour.Value * 60 * 60 + departMinute.Value * 60);
            var wayPoints = new List<Rest.Model.NodeSimple>();
            wayPoints.Add(new Rest.Model.NodeSimple { mapId = startNode.MapId, nodeId = startNode.Id });
            foreach (var o in wayPointsListBox.Items)
            {
                var item = o as NodeListItem;
                wayPoints.Add(new Rest.Model.NodeSimple { mapId = item.Node.MapId, nodeId = item.Node.Id });
            }
            wayPoints.Add(new Rest.Model.NodeSimple { mapId = endNode.MapId, nodeId = endNode.Id });
            try
            {
                //ret = Service.MapAlgo.FindPath(startNode, endNode, pathType, preferTransportType, crossType, departAt);
                ret = Service.MapAlgo.FindPaths(wayPoints, pathType, preferTransportType, crossType, departAt);
            }
            catch (Exception ex)
            {
                if (ex.ToString() == "BadRequest")
                {
                    MessageBox.Show("给定要求不存在可解的路径。可能的原因：\n" +
                        "1. 选择了“仅限自行车”但是途中存在必经道路不支持此种交通方式。\n" +
                        "2. 建筑物尚未连接至公共的路网。");
                }
                else
                {
                    MessageBox.Show("失败：" + ex.ToString());

                }
            }
            if (ret != default)
            {
                Service.MapGraphics.DrawPath(ret);
                this.estimateTime.Text = "预估时间：" + new TimeSpan(0, 0, ret.Time).ToString(@"hh'时'mm'分'ss'秒'");
                _prevPathRet = ret;
            }


        }

        private void preferFootButton_Click(object sender, RoutedEventArgs e)
        {
            preferTransportType = MapAlgo.TransportType.Foot;
        }

        private void preferBicycleButton_Click(object sender, RoutedEventArgs e)
        {
            preferTransportType = MapAlgo.TransportType.Bicycle;
        }

        private void selBusOrSubway_Click(object sender, RoutedEventArgs e)
        {
            crossType = Level.Subway;
        }

        private void selSchoolBus_Click(object sender, RoutedEventArgs e)
        {
            crossType = Level.Bus;
        }

        private void selTaxi_Click(object sender, RoutedEventArgs e)
        {
            crossType = Level.Car;
        }

        private void selShortestDistance_Click(object sender, RoutedEventArgs e)
        {
            pathType = MapAlgo.PathType.ShortestDistance;
        }

        private void selShortestTime_Click(object sender, RoutedEventArgs e)
        {
            pathType = MapAlgo.PathType.ShortestTime;
        }

        private void departHour_ValueChanged(object sender, HandyControl.Data.FunctionEventArgs<double> e)
        {

        }

        private void departMinute_ValueChanged(object sender, HandyControl.Data.FunctionEventArgs<double> e)
        {

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Runtime.Logger.Information("Entering program...");

        }

        private void Window_Unloaded(object sender, RoutedEventArgs e)
        {
            Runtime.Logger.Information("Exiting program...");
            Application.Current.Shutdown();
        }

        private void simulateTimeFactor_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (!this.IsLoaded) return;
            simulateTimeFactor.Value = Math.Floor(simulateTimeFactor.Value);
            simulateSpeedTextBox.Text = "速度倍率：" + simulateTimeFactor.Value + "x";

            Service.SimulatorService.footSpeed = footSpeedTextBox.Value * simulateTimeFactor.Value;
            Service.SimulatorService.bicycleSpeed = bicycleSpeedTextBox.Value * simulateTimeFactor.Value;

        }

        private void simulateStart_Click(object sender, RoutedEventArgs e)
        {
            if(default == _prevPathRet)
            {
                MessageBox.Show("请先生成路径！");
                return;
            }
            if (SimulatorService.IsRunning)
            {
                // MessageBox.Show("已经在模拟了！");
                simulateStart.Content = "开始模拟";
                simulationStatus.Content = "模拟被用户中止";
                SimulatorService.Cancel();
                startNode = SimulatorService.Nearest();

                UpdateSelNodeButton();
                UpdateLocationCursor();
                Service.MapGraphics.ClearPath();
                return;
            }
            simulationStatus.Content = "正在模拟...";
            SimulatorService.Run(_prevPathRet, this.Dispatcher, this.preferTransportType == MapAlgo.TransportType.Bicycle);
            simulateStart.Content = "停止模拟";
            SimulatorService.onFinish += () =>
            {
                this.Dispatcher.Invoke(() =>
                {
                    simulationStatus.Content = "模拟完成";
                    startNode = endNode;
                    UpdateNodeTextBox();
                    UpdateSelNodeButton();
                    UpdateLocationCursor();
                    Service.MapGraphics.ClearPath();
                    simulateStart.Content = "开始模拟";
                });
            };
            SimulatorService.onSwitchMap += (ulong from, ulong to) =>
             {
                 if(from == to)
                 {
                     return;
                 }
                 Runtime.Logger.Information($"Switch map, from Map{from}, to { to})");
                 this.Dispatcher.Invoke(() =>
                 {                     
                     OpenMapInTab(to);
                 });
             };
        }

        private void copyNodeInfoMenuItem_Click(object sender, RoutedEventArgs e)
        {
            if (default == nearest) return;
            Clipboard.SetText(nearest.ToString());
        }
        private void MapTab_Selected(object sender, SelectionChangedEventArgs e)
        {
            if ((!(e.Source is TabControl))) return;
            var selItem = (e.AddedItems[0] as TabItem);
            currentMapId = (ulong)(selItem.Tag);
            e.Handled = true;

        }

        private void nearby_Click(object sender, RoutedEventArgs e)
        {
            if (startNode == null)
            {
                MessageBox.Show("请先选择起点！");
                return;
            }
            var w = new AppWindow.NearbyViewWindow(startNode);
            w.NodeSelected = (Node n) =>
            {
                this.startNode = n;
                UpdateNodeTextBox();
                UpdateSelNodeButton();
                UpdateLocationCursor();
            };
            w.ShowDialog();
        }
        int wantOpen = 0;
        private void startPointTextBox_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            var w = new AppWindow.VirtualAdressSearch(currentMapId, departAt);
            w.NodeSelected += (Node n) =>
            {
                if (!Service.MapGraphics.IsOpen(n.MapId))
                {
                    OpenMapInTab(n.MapId);
                }
                currentMapId = n.MapId;
                this.startNode = n;
                UpdateNodeTextBox();
                UpdateSelNodeButton();
                UpdateLocationCursor();
                MessageBox.Show("已设置起点！");
            };
            w.ShowDialog();

        }

        private void endPointTextBox_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            var w = new AppWindow.VirtualAdressSearch(currentMapId, departAt);
            w.NodeSelected += (Node n) =>
            {
                if (!Service.MapGraphics.IsOpen(n.MapId))
                {
                    OpenMapInTab(n.MapId);
                }
                currentMapId = n.MapId;
                this.endNode = n;
                UpdateNodeTextBox();
                UpdateSelNodeButton();
                UpdateLocationCursor();

                MessageBox.Show("已设置终点！");
            };
            w.ShowDialog();

        }

        private void MapTab_MouseDown(object sender, MouseButtonEventArgs e)
        {

        }

        private void addWayPointBtn_Click(object sender, RoutedEventArgs e)
        {
            var selected = (bool)this.addWayPointBtn.IsChecked;
            this.addWayPointBtn.Content = selected ? "(捕获...)" : "添加";
            if (selected)
            {
                mode = OperationMode.SelectWayPoint;
            }
        }


        private void removeWayPointBtn_Click(object sender, RoutedEventArgs e)
        {
            var selected = wayPointsListBox.SelectedItems.Cast<Object>().ToArray();
            foreach (var item in selected) wayPointsListBox.Items.Remove(item);
            UpdateWayPoints();
            var count = wayPointsListBox.SelectedItems.Count;
        }

        private async void RestartServerMenuItem_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                await new System.Net.Http.HttpClient().GetAsync(Runtime.RebootUrl);
                MessageBox.Show("成功！");
            }
            catch (Exception ex)
            {
                {
                    MessageBox.Show("失败：" + ex.ToString());

                }

            }
        }

        private void selectAllWayPointsBtn_Click(object sender, RoutedEventArgs e)
        {
            wayPointsListBox.SelectAll();
        }

        private void footSpeedTextBox_ValueChanged(object sender, HandyControl.Data.FunctionEventArgs<double> e)
        {
            Service.SimulatorService.footSpeed = footSpeedTextBox.Value * simulateTimeFactor.Value;
        }

        private void bicycleSpeedTextBox_ValueChanged(object sender, HandyControl.Data.FunctionEventArgs<double> e)
        {
            Service.SimulatorService.bicycleSpeed = bicycleSpeedTextBox.Value * simulateTimeFactor.Value;
        }
    }
    enum OperationMode
    {
        None,
        SelectStartPoint,
        SelectEndPoint,
        SelectWayPoint
    }

    public class NodeListItem
    {
        public Node Node { get; set; }
        public string NodeStr { get; set; }
    }
}
