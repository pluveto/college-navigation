﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WpfNavigation.Model
{
    public class AddressMapper
    {
        public List<VirtualAddress> List { get; private set; } = new List<VirtualAddress>();
    }
}
