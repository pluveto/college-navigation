﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;

namespace WpfNavigation.Model
{
    public class Edge
    {
        public ulong Id;
        public ulong MapId;
        public int Level;
        public ulong SourceId;
        public ulong TargetId;

        public Edge(ulong id, ulong mapId, int level, ulong sourceId, ulong targetId)
        {
            Id = id;
            MapId = mapId;
            Level = level;
            SourceId = sourceId;
            TargetId = targetId;
        }
    }
}
