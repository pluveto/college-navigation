﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WpfNavigation.Model
{

    public class MapData
    {
        public ulong id;
        public string Name;
        public Dictionary<ulong, Node> Nodes = new Dictionary<ulong, Node>();
        public Dictionary<ulong, Edge> Edges = new Dictionary<ulong, Edge>();
        public Dictionary<ulong, double> Speed = new Dictionary<ulong, double>();
        public string BackgroundImageUri { get; internal set; }
    }
}
