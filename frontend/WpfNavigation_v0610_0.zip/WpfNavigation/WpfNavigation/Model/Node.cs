﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;

namespace WpfNavigation.Model
{
    public class Node
    {
        public ulong Id;
        public ulong MapId;
        public Point Point;
        public string Title;
        public string Subtitle;
        public Node(ulong id, ulong mapId, Point point)
        {
            Id = id;
            MapId = mapId;
            Point = point;
        }

        public override string ToString()
        {
            var title = Title == null ? "null" : Title;
            return $"Node(Id = {Id}, MapId = {MapId}, Location = {Point.X}, {Point.Y}, Title = {title})";
        }
    }
}
