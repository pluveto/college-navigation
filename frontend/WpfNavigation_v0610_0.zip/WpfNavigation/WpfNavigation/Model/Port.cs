﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WpfNavigation.Model
{
    public class Port
    {
        public ulong Id;
        public ulong Level;

        public ulong SourceMapId;


        public ulong SourceNodeId;
        public ulong TargetMapId;
        public ulong TargetNodeId;

        public Port(ulong id, ulong level, ulong sourceMapId, ulong sourceNodeId, ulong targetMapId, ulong targetNodeId)
        {
            Id = id;
            Level = level;
            SourceMapId = sourceMapId;
            SourceNodeId = sourceNodeId;
            TargetMapId = targetMapId;
            TargetNodeId = targetNodeId;
        }
    }

    public enum Level
    {
        Default = 0,
        Bicycle = 1,
        Car = 1 << 1,
        Bus = 1 << 2, // 用于跨校区
        Subway = 1 << 3, // 用于跨校区
        EnterBuilding = 1 << 4, // 用于主图到建筑内，建筑内之间
        ExitBuilding = 1 << 5, // 用于主图到建筑内，建筑内之间
        DownStair = 1 << 6, // 用于主图到建筑内，建筑内之间
        UpStair = 1 << 7, // 用于主图到建筑内，建筑内之间=
        Path = 1 << 15,
        HistoryPath = 1 << 16
    }
}
