﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace WpfNavigation.Model
{
    public class VirtualAddress
    {
        public IList<int> DayOfWeek;
        public long TimeStart { get; set; }
        public long TimeEnd { get; set; }
        public string Class { get; set; } // emtpy 代表不限
        public string Activity { get; set; }
        public ulong _MapId { get; set; }
        public ulong _NodeId { get; set; }

    }
}

