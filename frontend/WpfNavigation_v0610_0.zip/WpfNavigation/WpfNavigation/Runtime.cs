﻿using Newtonsoft.Json.Linq;
using Serilog;
using Serilog.Core;
using Serilog.Events;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Controls;
using WpfNavigation.Model;
using WpfNavigation.Rest;

namespace WpfNavigation
{
    public static class Runtime
    {
        public static string CurrentUsername { get; set; } = "debugger";

        public static string BaseUrl { get; set; } = "http://123.57.244.239:1926/";
        public static string RebootUrl { get; set; } = "http://123.57.244.239:1926/";
        public static ApiManager ApiManager { get; set; }

        public static bool DebugMode { get; set; } = true;
        public static Dictionary<ulong, Canvas> CanvasDict = new Dictionary<ulong, Canvas>();

        public static Dictionary<ulong, MapData> Maps { get; set; } = new Dictionary<ulong, MapData>();
        public static Dictionary<ulong, Port> Ports { get; set; } = new Dictionary<ulong, Port>();
        public static Logger Logger = new LoggerConfiguration()
                                        .MinimumLevel.Debug()
                                        .WriteTo.File("logs/dsnav.log")
                                        .WriteTo.Console(restrictedToMinimumLevel: LogEventLevel.Verbose)
                                        .CreateLogger();

        public static Dictionary<string, User> Users { get; set; }
    };
}
