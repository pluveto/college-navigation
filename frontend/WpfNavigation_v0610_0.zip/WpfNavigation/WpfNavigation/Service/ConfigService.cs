﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace WpfNavigation.Service
{
    /// <summary>
    /// 配置文件对象管理器
    /// </summary>
    public class ConfigService<T>
    {
        /// <summary>
        /// 缓存到内存的配置文件
        /// </summary>

        public string FileName { get; private set; }
        public T Object;
        public ConfigService(string fileName = "config.json")
        {
            this.FileName = fileName;
        }
        public T Load()
        {
            var json = File.ReadAllText(this.FileName);
            this.Object = JsonConvert.DeserializeObject<T>(json);
            return this.Object;
        }
        public void Save()
        {
            var json = JsonConvert.SerializeObject(Object);
            File.WriteAllText(this.FileName, json);
        }

    }
}
