﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using WpfNavigation.Model;
using WpfNavigation.Rest.Model;

namespace WpfNavigation.Service
{
    public static class MapAlgo
    {
        public static double CalculateCost(Edge edge, double timeFactor = 1)
        {
            var map = Runtime.Maps[edge.MapId];
            var src = map.Nodes[edge.SourceId];
            var tar = map.Nodes[edge.TargetId];
            var dist = DistanceSquare(src.Point.X, tar.Point.X, src.Point.Y, tar.Point.Y);
            return dist * timeFactor;
        }
        public static HashSet<Port> GetPortsBySourceNode(Node src)
        {
            var ret = new HashSet<Port>();
            foreach (var kv in Runtime.Ports)
            {
                if (kv.Value.SourceMapId == src.MapId && kv.Value.SourceNodeId == src.Id)
                {
                    ret.Add(kv.Value);
                }
            }
            return ret;

        }

        internal static List<KeyValuePair<Node, double>> SearchNearBy(Node startNode, double value, bool allowEmptyTitle = false)
        {
            var map = Runtime.Maps[startNode.MapId];
            var ret = new List<KeyValuePair<Node, double>>();
            var disSq = value * value;
            foreach (var mkv in map.Nodes)
            {
                if (mkv.Value == startNode)
                {
                    continue;
                }
                if(mkv.Value.Title == null || mkv.Value.Title.Length == 0 && !allowEmptyTitle)
                {
                    continue;
                }
                var d = DistanceSquare(startNode.Point, mkv.Value.Point);
                if (d < disSq)
                {
                    ret.Add(new KeyValuePair<Node, double>(mkv.Value, Math.Sqrt(d)));
                }
            }
            ret.ToList().Sort(
                delegate (KeyValuePair<Node, double> pair1, KeyValuePair<Node, double> pair2)
                {
                    return pair1.Value.CompareTo(pair2.Value);
                }
            );
            return ret;

        }

        internal static List<Node> SearchTitleSubtitle(string keywords, uint departAt)
        {
            LoadSpeeds(Rest.Api.MapApi.SpeedType.Node, departAt);
            var ret = new List<Node>();
            foreach (var mapKv in Runtime.Maps)
            {
                foreach (var nodeKv in mapKv.Value.Nodes)
                {
                    var title = nodeKv.Value.Title == default ? "" : nodeKv.Value.Title;
                    var subtitle = nodeKv.Value.Subtitle == default ? "" : nodeKv.Value.Subtitle;
                    if (title.Contains(keywords))
                    {
                        ret.Add(nodeKv.Value);
                    }else if (subtitle.Contains(keywords))
                    {
                        ret.Add(nodeKv.Value);
                    }
                }
            }
            return ret;
        }

        public static double CalculateCost(Dictionary<ulong, Node> nodes, Edge edge, double timeFactor = 1)
        {
            var src = nodes[edge.SourceId];
            var tar = nodes[edge.TargetId];
            var dist = DistanceSquare(src.Point.X, tar.Point.X, src.Point.Y, tar.Point.Y);
            return dist * timeFactor;
        }
        static Dictionary<Node, int> DistanceFromSource = new Dictionary<Node, int>();
        public enum PathType
        {
            ShortestDistance = 0,
            ShortestTime = 1
        }

        public enum TransportType
        {
            Foot = 0,
            Bicycle = 1
        }

        public static PathRet FindPath(Node from, Node to, PathType pathType, TransportType preferTransportType, Level crossType, uint departAt)
        {
            Runtime.Logger.Information($"Finding Path from: {from}, to: {to}");
            ulong sourceNodeId, targetNodeId, sourceMapId, targetMapId;
            sourceNodeId = from.Id;
            targetNodeId = to.Id;
            sourceMapId = from.MapId;
            targetMapId = to.MapId;
            return
                Util.AsyncHelper.RunSync<PathRet>(new Func<Task<PathRet>>(async () =>
                {

                    return await Runtime.ApiManager.Map.GetPathAsync(sourceNodeId, targetNodeId, sourceMapId, targetMapId, (uint)pathType, (uint)preferTransportType, departAt, (uint)crossType);

                })
            );
        }
        public static PathRet FindPaths(List<NodeSimple> nodes, PathType pathType, TransportType preferTransportType, Level crossType, uint departAt)
        {
            Runtime.Logger.Information($"Finding Path of waypoint from {nodes.First()} to {nodes.Last()}");
            foreach (var item in nodes)
            {
                Runtime.Logger.Information($"    Way point {item.nodeId} of Map {item.nodeId}");
            }
            return
                Util.AsyncHelper.RunSync<PathRet>(new Func<Task<PathRet>>(async () =>
                {
                    return await Runtime.ApiManager.Map.GetPathsAsync(nodes, (uint)pathType, (uint)preferTransportType, departAt, (uint)crossType);
                })
            );
        }
        public static void LoadSpeeds(Rest.Api.MapApi.SpeedType type, uint departAt)
        {
            foreach (var item in Runtime.Maps)
            {
                var id = item.Key;
                var values = Util.AsyncHelper.RunSync(new Func<Task<SpeedRet[]>>(async () =>
                {
                    return await Runtime.ApiManager.Map.GetSpeedsAsync(id, type, departAt);
                }));
                foreach (var value in values)
                {
                    item.Value.Speed[value.Id] = value.Speed;
                }
            }
        }

        public static Node ConvertNode(ulong mapId, JObject obj)
        {
            var data = (JObject)obj["data"];
            var id = ulong.Parse(data["id"].Value<string>());
            var title = data.ContainsKey("title") ? data["title"].Value<string>() : null;
            var subtitle = data.ContainsKey("subtitle") ? data["subtitle"].Value<string>() : null;

            var x = obj["position"]["x"].Value<int>();
            var y = obj["position"]["y"].Value<int>();

            Point p;
            p.X = x;
            p.Y = y;

            Node node = new Node(id, mapId, p);
            if (null != title) node.Title = title.Length == 0 ? null : title;
            if (null != subtitle) node.Subtitle = subtitle.Length == 0 ? null : subtitle;
            return node;
        }

        internal static Edge GetEdge(Node currentNode, Node nextNode)
        {
            var mapId = currentNode.MapId;
            if (mapId != nextNode.MapId)
            {
                throw new Exception("不同地图之间的节点不能求边！");
            }
            var edges = Runtime.Maps[mapId].Edges;
            foreach (var item in edges)
            {
                var edge = item.Value;
                if(edge.SourceId == currentNode.Id && edge.TargetId == nextNode.Id)
                {
                    return edge;
                }
                if (edge.SourceId == nextNode.Id && edge.TargetId == currentNode.Id)
                {
                    return edge;
                }
            }
            return null;
        }

        public static double DistanceSquare(Point p1, Point p2)
        {
            double x1 = p1.X;
            double x2 = p2.X;
            double y1 = p1.Y;
            double y2 = p2.Y; ;
            var ret = (x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2);
            return ret;
        }
        public static double DistanceSquare(double x1, double x2, double y1, double y2)
        {
            var ret = (x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2);
            return ret;
        }


        public static Node GetNeareastNode(MapData map, Point p)
        {
            var minDistance = double.MaxValue;
            Node ret = null;
            foreach (var node in map.Nodes)
            {
                var x1 = node.Value.Point.X;
                var y1 = node.Value.Point.Y;
                var x2 = p.X;
                var y2 = p.Y;
                var dis = DistanceSquare(x1, x2, y1, y2);
                if (minDistance > dis)
                {
                    minDistance = dis;
                    ret = node.Value;
                }
            }
            return ret;
        }
    }
}
