﻿using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using WpfNavigation.Model;
using WpfNavigation.Rest.Model;
using System.Timers;
using System.Windows.Input;
using System.Windows.Media.Imaging;
using System.Linq;

namespace WpfNavigation.Service
{
    public class MapGraphics
    {
        public static class MapColors
        {
            public static Brush Road = (Brush)(new BrushConverter().ConvertFrom("#ffffff"));
            public static Brush RoadBicycle = (Brush)(new BrushConverter().ConvertFrom("#c9801a"));
            public static Brush RoadBorder = (Brush)(new BrushConverter().ConvertFrom("#dfe1e4"));
            public static Brush Background = (Brush)(new BrushConverter().ConvertFrom("#f4f6f7"));
            public static Brush Path = (Brush)(new BrushConverter().ConvertFrom("#007acc"));
            public static Brush HistoryPath = (Brush)(new BrushConverter().ConvertFrom("#b0146e"));

        }
        static HashSet<ulong> _openedMapIds = new HashSet<ulong>();
        public static bool IsOpen(ulong MapId)
        {
            return _openedMapIds.Contains(MapId);
        }
        internal static TabItem OpenMap(TabControl mapTab, ulong mapId, MouseButtonEventHandler onMouseDown, MouseEventHandler onMouseMove)
        {
            if (_openedMapIds.Contains(mapId))
            {
                foreach (var item in mapTab.Items)
                {
                    var tabItm = item as TabItem;
                    if((ulong)tabItm.Tag == mapId)
                    {
                        return tabItm;
                    }
                }
            }

            var map = Runtime.Maps[mapId];

            var tab = new HandyControl.Controls.TabItem();
            var canvas = new Canvas();
            Runtime.CanvasDict.Add(mapId, canvas);
            tab.Header = new TextBlock() { Text = map.Name };
            tab.Content = canvas;
            tab.Tag = mapId;
            mapTab.Items.Add(tab);
            Service.MapGraphics.DrawMap(mapId);


            var img0 = new Image()
            {
                Stretch = Stretch.None,
                HorizontalAlignment = HorizontalAlignment.Left,
                VerticalAlignment = VerticalAlignment.Top,
                Width = 2000,
                Height = 2000,
                Source = new BitmapImage(new Uri(map.BackgroundImageUri)),
            };

            canvas.Children.Add(img0);
            canvas.MouseDown += onMouseDown;
            canvas.MouseMove += onMouseMove;

            canvas.MouseLeftButtonUp += Canvas_MouseLeftButtonUp;
            canvas.MouseLeftButtonDown += Canvas_MouseLeftButtonDown;
            canvas.MouseMove += Canvas_MouseMove;
            _openedMapIds.Add(mapId);
            return tab;

        }
        static Dictionary<Canvas, Point> last = new Dictionary<Canvas, Point>();
        private static void Canvas_MouseMove(object sender, MouseEventArgs e)
        {
            var c = sender as Canvas;
            if (!c.IsMouseCaptured)
                return;
            var cur = e.GetPosition(c);
            Matrix m = c.RenderTransform.Value;
            m.OffsetX += cur.X - last[c].X;
            m.OffsetY += cur.Y - last[c].Y;
            c.RenderTransform = new MatrixTransform(m);
        }

        private static void Canvas_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            var c = sender as Canvas;
            last[c] = e.GetPosition(c);
            c.CaptureMouse();

        }

        private static void Canvas_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            var c = sender as Canvas;
            c.ReleaseMouseCapture();

        }

        public static Canvas GetCanvas(ulong mapId)
        {            
            return Runtime.CanvasDict[mapId];

        }

        public static void Test()
        {
            // 红颜路
            /*DrawRoad(
                new Point[] { new Point(146,515.76),
                new Point(504,396.76),
                new Point(646,346.76),
                new Point(816,288.76),
                new Point(988,226.76),}
                ,10
                );*/
        }
        public static void LoadPort(string uri)
        {
            uri = System.IO.Path.GetFullPath(uri);
            var dir = System.IO.Path.GetDirectoryName(uri);
            var dict = Runtime.Ports;
            using (var file = File.OpenText(uri))
            using (var reader = new JsonTextReader(file))
            {
                var o = (JObject)JToken.ReadFrom(reader);
                foreach (var item in o["maps"])
                {
                    var id = item["id"].Value<ulong>();
                    var path = item["path"].Value<string>();
                    var name = item["name"].Value<string>();
                    var bgimg = item["bgimg"].Value<string>();
                    Service.MapGraphics.LoadMapData(id, System.IO.Path.Join(dir, path), name, System.IO.Path.Join(dir, bgimg));
                }
                foreach (var item in o["ports"])
                {
                    var id = item["id"].Value<ulong>();
                    var level = item["level"].Value<ulong>();
                    var sourceMapId = item["sourceMapId"].Value<ulong>();
                    var targetMapId = item["targetMapId"].Value<ulong>();
                    var sourceNodeId = item["sourceNodeId"].Value<ulong>();
                    var targetNodeId = item["targetNodeId"].Value<ulong>();

                    var port = new Port(id, level, sourceMapId, sourceNodeId, targetMapId, targetNodeId);
                    dict.Add(id, port);
                }
            }
        }
        public static void LoadMapData(ulong mapId, string uri, string name, string bgimg)
        {
            var mapData = new MapData();
            mapData.Name = name;
            mapData.BackgroundImageUri = bgimg;
            using (StreamReader file = File.OpenText(uri))
            using (JsonTextReader reader = new JsonTextReader(file))
            {
                var o = (JObject)JToken.ReadFrom(reader);
                foreach (var item in o["elements"]["nodes"])
                {
                    var node = MapAlgo.ConvertNode(mapId, (JObject)item);
                    mapData.Nodes.Add(node.Id, node);
                }
                foreach (var item in o["elements"]["edges"])
                {
                    var id = ulong.Parse(item["data"]["id"].Value<string>());
                    var sourceId = ulong.Parse(item["data"]["source"].Value<string>());
                    var targetId = ulong.Parse(item["data"]["target"].Value<string>());
                    var level = 0;
                    if (item["data"]["level"] != default)
                    {
                        level = item["data"]["level"].Value<int>();
                    }
                    var edge = new Edge(id, mapId, level, sourceId, targetId);
                    mapData.Edges.Add(id, edge);
                    var source = mapData.Nodes[sourceId];
                    var target = mapData.Nodes[targetId];
                    //var cost = MapAlgo.CalculateCost(edge);
                    //source.AdjacentNodes.Add(target, (int)cost);
                    //target.AdjacentNodes.Add(source, (int)cost);
                }
            }
            Runtime.Maps.Add(mapId, mapData);
        }
        public static void DrawMap(ulong mapId)
        {
            var mapData = Runtime.Maps[mapId];
            var canvas = Runtime.CanvasDict[mapId];

            canvas.Background = MapColors.Background;


            foreach (var e in mapData.Edges)
            {
                var sourcePt = mapData.Nodes[e.Value.SourceId].Point;
                var targetPt = mapData.Nodes[e.Value.TargetId].Point;
                DrawRoad(mapId, new Point[] { sourcePt, targetPt });

            }
            foreach (var nodekv in mapData.Nodes)
            {
                var node = nodekv.Value;
                if (node.Title != null)
                {
                    /*TextBlock textBlock = new TextBlock();
                    textBlock.Text = node.Title;
                    textBlock.Foreground = Brushes.GreenYellow;
                    Canvas.SetLeft(textBlock, node.Point.X);
                    Canvas.SetTop(textBlock, node.Point.Y);
                    canvas.Children.Add(textBlock);*/
                }

            }

        }

        /*
        public static void DrawRoad(IList<double> pts,double width = 5)
        {
        var c = GetCanvas();


        var lb = new Polyline();
        for (int i = 0; i < pts.Count; i += 2)
        {
        lb.Points.Add(new System.Windows.Point(pts[i], pts[i + 1]));
        }
        lb.Stroke = MapColors.RoadBorder;
        lb.StrokeThickness = width+2;
        c.Children.Add(lb);

        var l = new Polyline();
        for (int i = 0; i < pts.Count; i += 2)
        {
        l.Points.Add(new System.Windows.Point(pts[i], pts[i + 1]));
        }
        l.Stroke = MapColors.Road;
        l.StrokeThickness = width;

        c.Children.Add(l);
        }
        */
        public static void DrawRoad(ulong mapId, IList<Point> pts, double width = 5)
        {
            var c = GetCanvas(mapId);


            var lb = new Polyline();
            foreach (var pt in pts)
            {
                lb.Points.Add(pt);
            }
            lb.Stroke = MapColors.RoadBorder;
            lb.StrokeThickness = width + 2;
            c.Children.Add(lb);

            var l = new Polyline();

            foreach (var pt in pts)
            {
                l.Points.Add(pt);
            }
            l.Stroke = MapColors.Road;
            l.StrokeThickness = width;

            c.Children.Add(l);
        }
        public static Dictionary<Level, Brush> LevelBurshes = new Dictionary<Level, Brush> {
            { Level.Default, MapColors.Road },
            {Level.Bicycle, MapColors.RoadBicycle },
            { Level.Path, MapColors.Path },
            { Level.HistoryPath, MapColors.HistoryPath },
        };
        public static Brush GetBrush(Level level)
        {
            if (LevelBurshes.ContainsKey(level))
            {
                return LevelBurshes[level];
            }
            return MapColors.Road;
        }
        public static List<FrameworkElement> DrawRoad(Node node1, Node node2, Level l, bool border = true)
        {
            return DrawRoad(node1.MapId, (int)node1.Point.X, (int)node2.Point.X, (int)node1.Point.Y, (int)node2.Point.Y, l, border);
        }

        public static List<FrameworkElement> DrawRoad(ulong mapId, int x1, int x2, int y1, int y2, Level level = 0, bool drawBoard = true)
        {
            var ret = new List<FrameworkElement>();

            var c = GetCanvas(mapId);

            if (drawBoard)
            {



                var lb = new Line();

                lb.X1 = x1;
                lb.Y1 = y1;

                lb.X2 = x2;
                lb.Y2 = y2;

                lb.Stroke = MapColors.RoadBorder;

                lb.StrokeThickness = 7;

                c.Children.Add(lb);
                ret.Add(lb);

            }

            var l = new Line();

            l.X1 = x1;
            l.Y1 = y1;

            l.X2 = x2;
            l.Y2 = y2;

            l.Stroke = MapColors.Road;

            l.Stroke = GetBrush((Level)level);

            l.StrokeThickness = 5;

            c.Children.Add(l);
            ret.Add(l);
            return ret;
        }
        /// <summary>
        /// 暂存的路径，用于不再使用之后的销毁操作
        /// </summary>
        static List<FrameworkElement> PathBin = new List<FrameworkElement>();
        internal static void ClearPath()
        {
            foreach (var item in PathBin.ToArray())
            {
                (item.Parent as Canvas).Children.Remove(item);
                PathBin.Remove(item);

            }
        }
        internal static void DrawPath(PathRet ret)
        {
            ClearPath();
            var map = Runtime.Maps[ret.Value[0].mapId];
            var node = map.Nodes[ret.Value[0].Id];

            for (int i = 1; i < ret.Value.Length; i++)
            {
                var e = ret.Value[i];
                switch (e.Type.ToLower())
                {
                    case "node":
                        var nextNode = map.Nodes[e.Id];
                        var r = DrawRoad(node, nextNode, Level.Path, false);
                        PathBin.AddRange(r);
                        node = nextNode;
                        break;
                    case "port":
                        var port = Runtime.Ports[e.Id];
                        map = Runtime.Maps[port.TargetMapId];
                        node = map.Nodes[port.TargetNodeId];
                        break;
                    default:
                        break;
                }
            }
        }
    }
}
