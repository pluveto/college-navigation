﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;
using WpfNavigation.Model;
using WpfNavigation.Rest.Model;
using static WpfNavigation.Service.MapAlgo;

namespace WpfNavigation.Service
{
    public class SimulatorService
    {
        enum Status
        {
            Stop,
            Pause,
            Running
        }

        static Timer _timer = new Timer();

        // 模拟的状态信息
        static MapData _currentMap;
        static Node _currentNode;
        static Canvas _currentCanvas;
        static Point _currentPosition;

        public static Node Nearest()
        {
            return MapAlgo.GetNeareastNode(_currentMap, _currentPosition);
        }

        static TransportType _curTransportType;
        static FrameworkElement _currentLocationCursor = new Ellipse { Width = 16, Height = 16, Fill = Brushes.DarkBlue };
        static int _currentNodeIndex = 0;
        public delegate void OnFinish();
        public delegate void OnSwitchMap(ulong from, ulong to);
        public static OnFinish onFinish;
        public static OnSwitchMap onSwitchMap;
        public static double footSpeed { get; set; } = 30;// pixel per sec
        public static double bicycleSpeed { get; set; } = 30;// pixel per sec
        static PathRet _path;
        static Dispatcher _dispatcher;

        static int updateUICounter = 0;
        public static void Pause()
        {
            _timer.Enabled = false;
        }
        public static void Continue()
        {
            _timer.Enabled = true;
        }
        static void updateUI()
        {
            if (default == _dispatcher) return;
            if (updateUICounter != 3)
            {
                updateUICounter++;
                return;
            }
            updateUICounter = 0;
            _dispatcher.Invoke(() =>
            {
                try
                {
                    Canvas.SetLeft(_currentLocationCursor, _currentPosition.X - 8);
                    Canvas.SetTop(_currentLocationCursor, _currentPosition.Y - 8);
                }
                catch (Exception)
                {

                }
            });
            Runtime.Logger.Information($"Current location: ({ _currentPosition.X}, { _currentPosition.Y})");
        }
        public static void Stop()
        {
            _timer.Elapsed -= SimulationTimer_Elapsed;
            _timer.Stop();
            _currentNode = null;
            _currentNodeIndex = 0;
            _dispatcher.Invoke(() =>
            {
                _currentCanvas.Children.Remove(_currentLocationCursor);
            });
            IsRunning = false;
            _path = null;
            onFinish();
        }

        internal static void Cancel()
        {
            _timer.Elapsed -= SimulationTimer_Elapsed;
            _timer.Stop();
            _currentNode = null;
            _currentNodeIndex = 0;
            _dispatcher.Invoke(() =>
            {
                _currentCanvas.Children.Remove(_currentLocationCursor);
            });
            IsRunning = false;
            _path = null;
        }
        public static bool IsRunning = false;



        public static void Run(PathRet path, Dispatcher dispatcher, bool preferBicycle = false)
        {
            if (path == null)
            {
                MessageBox.Show("请先选择一条路径");
                return;
            }
            if (IsRunning)
            {
                return;
            }
            _dispatcher = dispatcher;
            Runtime.Logger.Information("Start simulation.");
            onFinish += () =>
             {
                 Runtime.Logger.Information("Finish simulation.");
             };
            _path = path;

            _timer.Interval = 10;
            _timer.Elapsed += SimulationTimer_Elapsed;
            _timer.Start();
            IsRunning = true;

        }        
        // 可以把这个回调看作一个特殊的循环，return 相当于 continue
        static void SimulationTimer_Elapsed(object sender, ElapsedEventArgs e)
        {

            // 如果当前状态为空，说明需要从头画点
            //  一般来说，这种情况出现在开始，以及一个 Port 之后的那个 Node。两种情况下，都需要重置地图，画布，等等。
            if (_currentNode == null)
            {
                var startPathElem = _path.Value[_currentNodeIndex];
                var newMap = Runtime.Maps[startPathElem.mapId];
                onSwitchMap(_currentMap == default ? 0:_currentMap.id, newMap.id);
                _currentMap = newMap;
                // 地图跟踪跳转
                

                _currentCanvas = Runtime.CanvasDict[startPathElem.mapId];
                _currentNode = _currentMap.Nodes[startPathElem.Id];
                _currentPosition = new Point(_currentNode.Point.X, _currentNode.Point.Y);
                _curTransportType = TransportType.Foot;
                // 游标可能要从一个画布移动到另一个画布
                if (_currentLocationCursor.Parent != null)
                {
                    _dispatcher.Invoke(() =>
                    {
                        (_currentLocationCursor.Parent as Canvas).Children.Remove(_currentLocationCursor);
                    });
                }
                _dispatcher.Invoke(() =>
                {
                    _currentCanvas.Children.Add(_currentLocationCursor);
                });
                updateUI();
            }
            // 如果没有下一个，则模拟结束
            if (_currentNodeIndex + 1 == _path.Value.Length)
            {
                Stop();
                return;
            }
            // 如果下个是 Port 而非 Node，则直接将当前状态信息重置
            var nextPathElem = _path.Value[_currentNodeIndex + 1];
            if (nextPathElem.Type.ToLower() == "port")
            {
                _currentNodeIndex += 2;
                _currentNode = null;
                return;
            }
            var _nextNodeIndex = _currentNodeIndex + 1;
            var _nextNode = _currentMap.Nodes[_path.Value[_nextNodeIndex].Id];
            _currentNode = _currentMap.Nodes[_path.Value[_currentNodeIndex].Id];
            // Assert nextNode.Type == "node"
            // 判断是否已经到达路段的终点
            if (MapAlgo.DistanceSquare(_currentPosition, _nextNode.Point) < 3)
            {
                // 如果到达，则设置新的终点
                _currentNodeIndex++;
                return;
            }
            var edge = Service.MapAlgo.GetEdge(_currentNode, _nextNode);
            // 否则就继续前往                
            //  求解方向向量
            var direction = (_nextNode.Point - _currentPosition); direction.Normalize();
            //  求解方向向量上的 deltaX,Y
            var speed = footSpeed;
            if (edge.Level == 1) { speed = bicycleSpeed; }
            var displacement = direction * _timer.Interval / 1000 * speed / 10;
            //  设置新的坐标
            _currentPosition += displacement;
            updateUI();
        }

    }
}
