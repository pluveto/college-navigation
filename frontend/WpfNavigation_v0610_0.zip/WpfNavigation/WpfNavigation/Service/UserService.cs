﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using WpfNavigation.Model;

namespace WpfNavigation.Service
{
    class UserService
    {
        public static bool Login(string username, string password)
        {
            LoadUsers();
            if (Runtime.Users.ContainsKey(username) && Runtime.Users[username].Password == password)
            {
                return true;
            }
            return false;
        }

        private static void LoadUsers()
        {
            var jstr = System.IO.File.ReadAllText("../users.json");
            Runtime.Users = JsonConvert.DeserializeObject<Dictionary<string, User>>(jstr);

        }
    }
}