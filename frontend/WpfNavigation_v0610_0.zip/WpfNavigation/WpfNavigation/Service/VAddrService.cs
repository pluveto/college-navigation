﻿using System;
using System.Collections.Generic;
using System.Text;
using WpfNavigation.Model;

namespace WpfNavigation.Service
{
    class VAddrService
    {
        /// <summary>
        /// 2019211306班-数据结构课-周五10点，或者2019211306班-数据结构课-考场，或者食堂等
        /// </summary>
        /// <param name="s"></param>
        /// <returns></returns>
        public static VirtualAddress FromString(string s)
        {
            s = s.Replace("-考场", "考试");
            var tokens = s.Split("-");
            if (tokens.Length == 1)
            {
                return null;
            }
            else
            if (tokens.Length == 2)
            {
                return new VirtualAddress()
                {
                    DayOfWeek = new List<int>(),
                    TimeStart = 0,
                    TimeEnd = 0,
                    Class = tokens[0].Replace("班", ""),
                    Activity = tokens[1].Replace("课", ""),
                };
            }
            else
            if (tokens.Length == 3)
            {
                string timestr;
                var dow = ConvertChineseDayOfWeek(tokens[2], out timestr);
                if (-1 == dow) return null;
                return new VirtualAddress()
                {
                    DayOfWeek = new List<int> { dow },
                    TimeStart = ConvertChineseTime(timestr),
                    TimeEnd = ConvertChineseTime(timestr),
                    Class = tokens[0].Replace("班", ""),
                    Activity = tokens[1].Replace("课", ""),
                };
            }
            return null;
        }

        internal static Node MatchAddr(VirtualAddress vaddr, User user)
        {

            foreach (var item in user.AddressMapper.List)
            {
                if (Service.VAddrService.IsSubOf(vaddr, item))
                {
                    return Runtime.Maps[item._MapId].Nodes[item._NodeId];
                }
            }
            return null;
        }

        internal static List<Node> SearchActivity(string keywords, User user)
        {
            var l = new List<Node>();
            foreach (var item in user.AddressMapper.List)
            {
                if (item.Activity.Contains(keywords) || keywords.Contains(item.Activity))
                {
                    l.Add(Runtime.Maps[item._MapId].Nodes[item._NodeId]);
                }
            }
            return l;
        }

        private static bool IsSubOf(VirtualAddress vaddr, VirtualAddress item)
        {
            if (item.Activity != vaddr.Activity)
            {
                return false;
            }
            if (item.Class != vaddr.Class)
            {
                return false;
            }
            if (!hasSame(item.DayOfWeek, vaddr.DayOfWeek) && vaddr.DayOfWeek.Count != 0)
            {
                return false;
            }
            if (vaddr.TimeEnd == 0 && vaddr.TimeStart == 0)
            {
                return true;
            }
            if (!(item.TimeEnd >= vaddr.TimeEnd && vaddr.TimeStart >= item.TimeStart))
            {
                return false;
            }
            return true;
        }
        public static bool hasSame(IList<int> list, IList<int> list2)
        {

            foreach (var item in list2)
            {
                if (list.Contains(item))
                {
                    return true;
                }
            }
            return false;
        }
        public static int ConvertTimeOfDay(int h = 0, int m = 0, int s = 0)
        {
            return h * 3600 + m * 60 + s;
        }
        public static void ConvertTimeOfDay(int secs, out int h, out int m, out int s)
        {
            h = secs % 3600;
            var secs_m = secs - h * 3600;
            m = secs_m % 60;
            var secs_s = secs_m - m * 60;
            s = secs_s;
        }
        public static int ConvertChineseDayOfWeek(string s, out string clear)
        {
            var ret = -1;
            if (s.Contains("周天") || s.Contains("周日") || s.Contains("星期天") || s.Contains("星期日"))
                ret = 0;
            if (s.Contains("周一") || s.Contains("星期一")) ret = 1;
            if (s.Contains("周二") || s.Contains("星期二")) ret = 2;
            if (s.Contains("周三") || s.Contains("星期三")) ret = 3;
            if (s.Contains("周四") || s.Contains("星期四")) ret = 4;
            if (s.Contains("周五") || s.Contains("星期五")) ret = 5;
            if (s.Contains("周六") || s.Contains("星期六")) ret = 6;
            clear = s.Replace("周天", "").Replace("周日", "").Replace("星期天", "")
                        .Replace("星期日", "").Replace("周一", "").Replace("星期一", "")
                        .Replace("周二", "").Replace("星期二", "").Replace("周三", "")
                        .Replace("星期三", "").Replace("周四", "").Replace("星期四", "")
                        .Replace("周五", "").Replace("星期五", "").Replace("周六", "")
                        .Replace("星期六", "");
            return ret;
        }
        public static int ConvertChineseTime(string s)
        {
            var tokens = s.Split("点");
            if (tokens[0] == s)
            {
                tokens = s.Split("时");
            }
            var num0 = ConvertChineseNumber(tokens[0]);
            var num1 = tokens.Length > 1 ? ConvertChineseNumber(tokens[1]) : 0;
            return num0 * 60 * 60 + num1 * 60;
        }
        private static int ConvertChineseNumber(string s)
        {
            int num;
            if (int.TryParse(s, out num))
            {
                return num;
            }
            if (s == "半")
            {
                return 30;
            }
            if (s == "整" || s == "正")
            {
                return 0;
            }
            Dictionary<string, int> digit =
                new Dictionary<string, int>()
                { { "一", 1 },
                  { "二", 2 },
                  { "三", 3 },
                  { "四", 4 },
                  { "五", 5 },
                  { "六", 6 },
                  { "七", 7 },
                  { "八", 8 },
                  { "九", 9 } };

            Dictionary<string, int> ten =
                new Dictionary<string, int>()
                { { "十", 10 } };

            int ret = 0;

            s = s.Replace("零", "");
            int index = 0;
            int t_l = 0, _t_l = 0;
            string t_s;

            while (s.Length > index)
            {
                t_s = s.Substring(index++, 1);

                // 數字
                if (digit.ContainsKey(t_s))
                {
                    _t_l += digit[t_s];
                }
                // 十
                else if (ten.ContainsKey(t_s))
                {
                    _t_l = _t_l == 0 ? 10 : _t_l * 10;
                }


            }
            ret += t_l;
            ret += _t_l;

            return ret;
        }
    }
}
