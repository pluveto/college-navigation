﻿using System;
using System.Diagnostics;
using System.IO;

namespace run
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("starting...");
            var path = Environment.CurrentDirectory + @"\data\netcoreapp3.1\WpfNavigation.exe";
            Process process = new Process()
            {
                StartInfo = new ProcessStartInfo(path)
                {
                    WindowStyle = ProcessWindowStyle.Normal,
                    WorkingDirectory = Path.GetDirectoryName(path)
                }
            };
            process.Start();
            System.Threading.Thread.Sleep(1000);
        }
    }
}
